package responseValidate;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import java.util.concurrent.TimeUnit;

public class Validate_ResponseTimeTest {

	@Test
	public void validateResponseTime() 
	{
		baseURI = "http://localhost";
		port = 8084;
		
		Response res = when().get("projects");
		
		res.then().assertThat()
		.time(Matchers.lessThan(1500L), TimeUnit.MICROSECONDS);
	}

	
}
