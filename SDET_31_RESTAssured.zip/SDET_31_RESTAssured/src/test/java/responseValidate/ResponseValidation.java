package responseValidate;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ResponseValidation {

	@Test
	public void newResponseVal()
	{
		
		JSONObject j1= new JSONObject();
		j1.put("Name", "Morphius");
		j1.put("Title", "QA auto");
		
		JSONObject j= new JSONObject();
		j.put("EMP", "QA-ENG");
		j.put("QA-ENG", "3");
		j.put("EMP Details", j1);
		
		
		RequestSpecification reqSpecs = RestAssured.given();
		
//		reqSpecs.auth().oauth2("SomeToken");
		reqSpecs.contentType(ContentType.JSON);
		reqSpecs.body(j);
		
		Response resp = reqSpecs.post("https://reqres.in/api/users");

		resp.then().assertThat().statusCode(201);
		resp.then().log().all();
	}
	
	@Test
	public void resValidation()
	{
		
	}
}
