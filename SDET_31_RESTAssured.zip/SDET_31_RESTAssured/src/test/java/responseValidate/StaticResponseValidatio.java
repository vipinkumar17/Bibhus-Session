package responseValidate;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class StaticResponseValidatio {

	@Test
	public void staticRes() {
		baseURI="http://localhost";
		port=8084;
		
		String expData="TY_PROJ_002";
		
		Response res = when().get("projects");
		
		String actData = res.jsonPath().get("[0].projectId");
		Assert.assertEquals(expData, actData );
		System.out.println("Data fetch completed");
		
	}
}
