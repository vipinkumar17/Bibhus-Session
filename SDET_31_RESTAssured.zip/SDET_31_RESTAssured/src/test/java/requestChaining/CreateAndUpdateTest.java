package requestChaining;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojoClass.ProjectLibrary;

import static io.restassured.RestAssured.*;

import java.util.Random;

public class CreateAndUpdateTest {
	
	@Test
	public void createAndupdate() {

	baseURI="http://localhost";
	port=8084;
	Random r= new Random();
	int random=r.nextInt(100);
	
	ProjectLibrary pLib= new ProjectLibrary("Bibhudatta", "TYSS"+random, "On Going", 12);
	
	Response res=given()
	.body(pLib)
	.contentType(ContentType.JSON)
	
	.when()
	.post("/addProject");
	
	String projId=res.jsonPath().get("projectId");
	System.err.println(projId);
	
	String projName= res.jsonPath().get("projectName");
	System.out.println(projName);
	
	
	ProjectLibrary pLib1= new ProjectLibrary("Bibhudatta", projName, "Created", 12);
	
	given()
	.body(pLib1)
	.contentType(ContentType.JSON)
	.pathParam("pId", projId)
	
	.when()
	.put("/projects/{pId}")
	
	.then().log().all();
	
	
	
	}
}











