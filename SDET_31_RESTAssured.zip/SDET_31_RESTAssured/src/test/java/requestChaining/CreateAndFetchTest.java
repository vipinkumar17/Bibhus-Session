package requestChaining;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojoClass.ProjectLibrary;

import static io.restassured.RestAssured.*;

import java.util.Random;

public class CreateAndFetchTest {
	
	@Test
	public void createAndFetch() {

		baseURI="http://localhost";
		port=8084;
		
		Random r=new Random();
		int random=r.nextInt(100);
	
		ProjectLibrary pLib= new ProjectLibrary("Bibhudatta", "TYSS"+random, "On Going", 10);

		Response res = given()
		.body(pLib)
		.contentType(ContentType.JSON)
		
		.when()
		.post("/addProject");
		
		String capturedProjectId = res.jsonPath().get("projectId");
		System.err.println(capturedProjectId);
		
		when().get("/projects/capturedProjectId")
		
		.then().log().all();
		
	}

}













