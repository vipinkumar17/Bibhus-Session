import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CurlExample {
    public static void main(String[] args) {
        try {
            // Your Curl command
            String curlCommand = "curl 'https://qa-1-api.staging.aspireapp.com/v1/businesses/9ab85250-8ff3-4120-a033-d65f2d2512c3?_fields\\[\\]=uuid&_fields\\[\\]=name&_fields\\[\\]=province&_fields\\[\\]=state_code&_fields\\[\\]=website_url&_fields\\[\\]=reference_code&_fields\\[\\]=is_cla_eligible&_fields\\[\\]=registration_number&_fields\\[\\]=tax_registration_number&_fields\\[\\]=role&_fields\\[\\]=role_slug&_fields\\[\\]=analytics_id&_fields\\[\\]=business_model&_fields\\[\\]=registration_type&_fields\\[\\]=last_credit_limit_application.uuid&_fields\\[\\]=authorizations&_fields\\[\\]=eligibility.authorizations&_fields\\[\\]=eligibility.reason&_fields\\[\\]=has_budget&_fields\\[\\]=type&_fields\\[\\]=has_active_approval_policy&_fields\\[\\]=has_enabled_2fa&_fields\\[\\]=is_hk_nium_va&_fields\\[\\]=country&_fields\\[\\]=requirements&_fields\\[\\]=permissions_slugs&_fields\\[\\]=state&_fields\\[\\]=addresses.uuid&_fields\\[\\]=addresses.is_primary&_fields\\[\\]=primary_address.uuid&_fields\\[\\]=primary_address.address&_fields\\[\\]=primary_address.address_2&_fields\\[\\]=primary_address.address_3&_fields\\[\\]=primary_address.address_4&_fields\\[\\]=primary_address.postcode&_fields\\[\\]=primary_address.locality&_fields\\[\\]=primary_address.administrative_area&_fields\\[\\]=primary_address.country&_fields\\[\\]=application.reference_code&_fields\\[\\]=application.settings&_fields\\[\\]=industry_type.uuid&_fields\\[\\]=industry_type.type&_fields\\[\\]=industry_type.parent.uuid&_fields\\[\\]=industry_type.parent.type&_fields\\[\\]=country_incorporation.code&_fields\\[\\]=country_incorporation.currency.code&_fields\\[\\]=registration_role&_fields\\[\\]=bills_email&_fields\\[\\]=receipts_email&_fields\\[\\]=claim_payout_debit_account.uuid&_fields\\[\\]=claim_payout_debit_account.currency&_fields\\[\\]=claim_payout_debit_account.currency_code&_fields\\[\\]=activation_reward_info' \\\r\n"
            		+ "  -H 'authority: qa-1-api.staging.aspireapp.com' \\\r\n"
            		+ "  -H 'accept: application/json, text/plain, */*' \\\r\n"
            		+ "  -H 'accept-language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7' \\\r\n"
            		+ "  -H 'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiwianRpIjoiNWFlYTZmYTI3NGU1OTE4Yzc1MDgxOGY2ODFlMDFhM2IxODhlMjgwMTIxZWFmNDNiMTM0MjY0ZmQ1N2E4ODcyNDA1YTlmZDQ3MDZjY2ZkNTYiLCJpYXQiOjE3MDE4NDU4MDQuMjE4OTYyLCJuYmYiOjE3MDE4NDU4MDQuMjE4OTYzLCJleHAiOjE3MDE4NTMwMDQuMTgwMDcsInN1YiI6IjY0MDQwIiwic2NvcGVzIjpbXX0.AtoGRtHe_6MAtXnvBnEuJHQ-ItMvDlB2V_RJi46GME6wLieoUJeTI2ds86xcXxglHquG7y7uL-0oF6ytB7oN7U2qTLe-BNcCnfKVkxsaSnN5bQXYWMqZJqkegoecJr6QaPXmfrvA1-OjSFiKeHoZK6zcFe6hQasZie9TUgW7aVti9c_DOUPZcKFIUky-XNaM3V0IiKf4i3uYYqtqrYaoiQW1ku2AC9VC0CmgFUlG1RQDg6FlJveDyUa1xK1T1wZFIclFCO1BpedBuC1G2i_iE_iyp6jfkMcH5uY29nYPPHGqpcfk_6TIqu4fPCgw71LMniQOpqIqgbHQd1fBSEyWGULR1M6cOzU05eyXIcL364zQdZUzUY8teiYXhqRmNzF1EA6lcEY-6iASujzV8dp9DHba8OdOKZBFWyvFqQ0s3H9OTQ8YtwnLpJw1kZDUaO8Yur4UFukHOE5PEY5UW6IRcMYxFG2JceCm_8bimlQVpdD3zLhrupOEyszD2J9lxkwgMhwNLfGJaOGsFUuQ03mwBCYL-tUounhf5tzcalYow0Qw7_QNrz1ZEDTgvdXintGsSHzxMqXJaHRd7aK_I3LGtvSlrxPNEsvW63N9CeNLftOqq9G-2SZpDJPHtkcFNZA6lJeRRng0zm9mYJq9T9syLpaKNsmnk1XLX5ZNlQbJb0c' \\\r\n"
            		+ "  -H 'origin: https://qa-1-fe.staging.aspireapp.com' \\\r\n"
            		+ "  -H 'referer: https://qa-1-fe.staging.aspireapp.com/' \\\r\n"
            		+ "  -H 'sec-ch-ua: \"Google Chrome\";v=\"119\", \"Chromium\";v=\"119\", \"Not?A_Brand\";v=\"24\"' \\\r\n"
            		+ "  -H 'sec-ch-ua-mobile: ?0' \\\r\n"
            		+ "  -H 'sec-ch-ua-platform: \"Windows\"' \\\r\n"
            		+ "  -H 'sec-fetch-dest: empty' \\\r\n"
            		+ "  -H 'sec-fetch-mode: cors' \\\r\n"
            		+ "  -H 'sec-fetch-site: same-site' \\\r\n"
            		+ "  -H 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36' \\\r\n"
            		+ "  -H 'x-aspire-account-uuid;' \\\r\n"
            		+ "  -H 'x-aspire-additional-token;' \\\r\n"
            		+ "  -H 'x-aspire-application: CNSING' \\\r\n"
            		+ "  -H 'x-aspire-business-uuid: 9ab85250-8ff3-4120-a033-d65f2d2512c3' \\\r\n"
            		+ "  -H 'x-aspire-request-from: web/desktop' \\\r\n"
            		+ "  --compressed";

            // Execute Curl command
            ProcessBuilder processBuilder = new ProcessBuilder(curlCommand.split("\\s+"));
            Process process = processBuilder.start();

            // Read the output
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            // Wait for the process to finish
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
