package Practice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Parsher {

	public static void main(String[] args) {
		ObjectMapper mapper = new ObjectMapper();
		String carProperties = "{\"type\": \"Audi\", \"clolor\":\"Red\"}";
		
		try {
			Car c= mapper.readValue(carProperties, Car.class);
			
			System.out.println("Car brand is "+ c.getType());
			System.out.println("Car color is "+ c.getColor());
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
	}
}
