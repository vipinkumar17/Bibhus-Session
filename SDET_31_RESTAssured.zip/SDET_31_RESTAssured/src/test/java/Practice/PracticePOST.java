package Practice;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PracticePOST {

	
	@Test
	public void addUser()
	{
		baseURI="https://reqres.in";
		String endP= "/api/users";
		
		JSONObject jObj= new JSONObject();
		jObj.put("name", "morpheus");
		jObj.put("job", "leader");
		
		when().get(endP)
		
		.then().log().all();
	}
	
}
