package authentication;

import org.testng.annotations.Test;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
/**
 * Using COOPS API.
 * 
 * @author Lenovo
 *
 */
public class OAuth2Test {

	@Test
	public void Oauth2UsingCOOPs() {
		
		Response res = given()
		.formParam("client_id","NewAppForPrac")
		.formParam("client_secret", "f12d9bee631ef8f5094730d3612f3890")
		.formParam("grant_type", "authorization_code")
		.formParam("redirect_uri", "http://newappforprac.com")
		.formParam("code", "authorization_code")
		
		.when()
		.post("http://coop.apps.symfonycasts.com/token");
		
		String token=res.jsonPath().get("access_token");
		System.err.println(token);
		
		given()
		.auth()
		.oauth2(token)
		.pathParam("ID", 3210)
		
		.when()
		.post("http://coop.apps.symfonycasts.com/api/{ID}/chickens-feed")
		
		.then().log().all();
		
		
	}
}

