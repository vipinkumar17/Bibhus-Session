package authentication;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.*;

public class BearerToken {

	@Test
	public void bearerTokenAuth() {

	baseURI="https://api.github.com";
	
	JSONObject jObj= new JSONObject();
	jObj.put("name", "RepoCreatedUsing_BearerToken");
	jObj.put("description", "Just for practice");
	
	given()
	.auth()
	.oauth2("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")
	
	
	.body(jObj)
	.contentType(ContentType.JSON)
	
	.when()
	.post("/user/repos")
	
	.then().log().all();
	
	}
	
	@Test
	public void demo()
	{
		baseURI="https://api.github.com";
		
		JSONObject jObj= new JSONObject();
		jObj.put("name", "RepoCreatedUsing_BearerToken");
		jObj.put("description", "Just for practice");
		
	
	}
}
