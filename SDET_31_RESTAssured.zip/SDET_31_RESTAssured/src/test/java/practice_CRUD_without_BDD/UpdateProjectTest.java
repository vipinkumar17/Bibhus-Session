package practice_CRUD_without_BDD;

import java.util.Random;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateProjectTest {
	
	@Test
	public void UpdateProjectTest() {
		
		Random r= new Random();
		int ran=r.nextInt(1000);
		
		//Step 1: Create Required Data.
		
		JSONObject jobj= new JSONObject();
		jobj.put("craetedBy", "Bibhudatta");
		jobj.put("projectName", "Project_363");
		jobj.put("status", "Completed");
		jobj.put("teamSize", 5);
		
		//Step 2: create a Request.
		RequestSpecification req = RestAssured.given();
		
		Response res = req.put("http://localhost:8084/projects/TY_PROJ_3003");
		//step 3: Validate the response. 
		
		res.then().log().all();
		System.out.println(res.prettyPrint());
		
	}

}
