package practice_CRUD_without_BDD;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetProject_internetTest {
	@Test
	public void fetchProjects() {
		
		//step 1: define baseURI 
		RestAssured.baseURI="http://localhost:8084/projects";
		
		//step 2: 
		
		RequestSpecification req = RestAssured.given();
	
		//Step 3:
		
		Response res = req.request(Method.GET,"");
		res.then().log().all();
		System.err.println(res.prettyPrint());
	
	}
}
