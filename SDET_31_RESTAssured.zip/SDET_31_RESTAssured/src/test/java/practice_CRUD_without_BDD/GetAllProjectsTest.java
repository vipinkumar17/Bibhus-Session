package practice_CRUD_without_BDD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class GetAllProjectsTest {

	@Test
	public void fetchAllProjectsTest() {
		String exp= "HTTP/1.1 200 ";
		//Step 1: Create nacessary data.
		
		//Step 2: Create a Request;
		
		RequestSpecification req = RestAssured.given();
		
		
	

		
		Response res = req.get("http://localhost:8084/projects/");
				
				String s= res.jsonPath().getString("projectId");
				System.out.println(s);
				
				ResponseBody s1=res.getBody();
				System.err.println(s1.asPrettyString());
				
		//Step 3: Validate the resquest and reponse.
		 res.then().log().all();
		 String act =res.getStatusLine();
		 Assert.assertEquals(act, exp);
	}
}
