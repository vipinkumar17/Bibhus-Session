package practice_CRUD_without_BDD;

import java.util.Random;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class CreateProjectTest {
	@Test
	public void createProjectTest() {
		
		Random r= new Random();
		int ran=r.nextInt(1000);
		
		//Step 1 : create the datas - Necessary body.
		
		JSONObject jobj= new JSONObject();
		
		jobj.put("craetedBy", "Bibhudatta");
		jobj.put("projectName", "Project_"+ran);
		jobj.put("status", "On Going");
		jobj.put("teamSize", 10);
		
		//step 2 : send the Request.
		RequestSpecification req = RestAssured.given();
		req.body(jobj);
		req.contentType(ContentType.JSON);
		
		Response res = req.post("http://localhost:8084/addProject");
		
		
		//Step 3 : Validate the Response.
		
		ValidatableResponse val=res.then();
		val.assertThat().statusCode(201);
		System.err.println("Created successfully");
		
		res.then().log().all();
		
		/*
		 * System.out.println(res.asPrettyString());
		 * System.out.println(res.asString());
		 * System.out.println(res.prettyPrint()); 
		 * System.out.println(res.prettyPeek());
		 * 
		 * System.out.println("--------------------------------");
		 */
	
		
		
		System.err.println(res.getContentType());
		System.err.println(res.getTime());
		System.err.println(res.getSessionId());
		System.err.println(res.getStatusCode());
	}
}






















