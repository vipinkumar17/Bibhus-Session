package practice_CRUD_without_BDD;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteProject {
	
	@Test
	public void deleteProject() {
		//Step 1: Create reqired data.
		
		
		//Step 2: Create a Request.
		Response res = RestAssured.delete("http://localhost:8084/projects/TY_PROJ_606");
		
		//Step 3: Validate the Response.
		
		System.out.println("Deletion completed");
	}

}
