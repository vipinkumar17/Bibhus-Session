package practice_CRUD_without_BDD;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetProjects_WO_givenTest {
	
	@Test
	public void getProjectWOGivenTest() {
		
		String expConType="application/json";
		int expStaCode= 200;
		
		//Step 1 : create the data.
		    /*not needed, becoz we are doing get oparation*/
		
		//step 2 : send the Request.
		Response res = RestAssured.get("http://localhost:8084/projects/TY_PROJ_2004");
		
		//Step 3 : Validate the Response.
		res.then().log().all();
		
		String actContType=res.getContentType();
		int actStaCode=res.getStatusCode();
		
		           //TestNG Assertions
		Assert.assertEquals(expConType, actContType);
		Assert.assertEquals(expStaCode, actStaCode);
	}
}

















