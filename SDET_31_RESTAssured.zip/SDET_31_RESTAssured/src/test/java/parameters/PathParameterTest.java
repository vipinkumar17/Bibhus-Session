package parameters;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class PathParameterTest {
	@Test
	public void fetchUsingPathParam() {

		baseURI="http://localhost";
		port=8084;


		given()
		.pathParam("pid", "TY_PROJ_602")

		.when().get("/projects/{pid}")
		
		.then().log().all();
		
	}

}
