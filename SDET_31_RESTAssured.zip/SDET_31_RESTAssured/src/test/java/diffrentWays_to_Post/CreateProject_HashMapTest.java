package diffrentWays_to_Post;

import java.util.HashMap;
import java.util.Random;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateProject_HashMapTest {

	@Test
	public void CreateProject_HashMapTest() {
		
		Random r= new Random();
		int ran= r.nextInt(100);
		
		HashMap hs= new HashMap();
		hs.put("createdBy", "Bibhudatta");
		hs.put("projectName", "proj"+ran);
		hs.put("status", "On Going");
		hs.put("teamSize", 10);
		
		RequestSpecification req = RestAssured.given();
		req.body(hs);
		req.contentType(ContentType.JSON);
		
		Response res=req.post("http://localhost:8084/addProject");
		
		
		res.then().log().all();
	}
}
