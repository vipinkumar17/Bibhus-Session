package diffrentWays_to_Post;

import java.util.HashMap;
import java.util.Random;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class CreateProject_HashMap_With_BDDTest {

	@Test
	public void CreateProject_HashMapTest() {
		
		Random r= new Random();
		int ran= r.nextInt(100);
		
		baseURI="http://localhost";
		port=8084;
		
		HashMap hs= new HashMap();
		hs.put("createdBy", "Bibhudatta");
		hs.put("projectName", "proj"+ran);
		hs.put("status", "On Going");
		hs.put("teamSize", 10);
		
		given()
		.body(hs)
		.contentType(ContentType.JSON)
		
		
		.when()
		.post("/addProject")
		
		.then()
		.assertThat().statusCode(201).log().all();
		
	}
}
