package diffrentWays_to_Post;

import java.util.Random;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import pojoClass.ProjectLibrary;

import static io.restassured.RestAssured.*;

public class CreateProjectWith_POJO_Class {

	@Test
	public void createProject() {
		Random r= new Random();
		int random=r.nextInt(500);
		baseURI="http://localhost";
		port= 8084;
		
		ProjectLibrary pLib= new ProjectLibrary("Bibhudatta", "tyss_"+random, "Craeted", 10);
		
		given()
		.body(pLib)
		.contentType(ContentType.JSON)
		
		.when()
		.post("/addProject")
		
		.then()
		.log().all()
		.assertThat().statusCode(201);
		
	}
}
