package diffrentWays_to_Post;

import java.util.Random;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class CreateProjectWith_JSON_Object {

	@Test
	public void createProject() {
		
		Random r= new Random();
		int ran=r.nextInt(500);
		
		baseURI="http://localhost";
		port=8084;
		
		JSONObject jobj= new JSONObject();
		jobj.put("createdBy", "Bibhudatta");
		jobj.put("projectName", "proj"+ran);
		jobj.put("status", "On Going");
		jobj.put("teamSize", 10);
		
		given()
		.body(jobj)
		.contentType(ContentType.JSON)
		
		.when()
		.post("/addProject")
		
		.then().log().all().assertThat().statusCode(201);
	
		
	}
}
