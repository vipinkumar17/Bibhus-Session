package diffrentWays_to_Post;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

import java.io.File;

public class CreateProjectWith_JSON_File {

	@Test
	public void createProject() {
		
		baseURI="http://localhost";
		port=8084;
		File file = new File("./Data.json");
		
		given()
		.body(file)
		.contentType(ContentType.JSON)
		
		.when()
		.post("/addProject")
		
		.then()
		.log().all();
	}
}
