package dataDrivenTesting_dataProvider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojoClass.ProjectLibrary;

import static io.restassured.RestAssured.*;

import java.util.Random;

public class DataDrivenTestingTest {

	@Test (dataProvider= "fetchFromHere")
	public void createProject(String createdBy , String projectName, String status , int teamSize) {

		baseURI="http://localhost";
		port=8084;

		Random r = new Random();
		int random=r.nextInt(100);

		ProjectLibrary pLib= new ProjectLibrary(createdBy, projectName+random, status, teamSize);

		Response res = given()
				.body(pLib)
				.contentType(ContentType.JSON)

				.when()
				.post("/addProject");

		res.then().assertThat().statusCode(201);

	}
	@DataProvider
	public Object[][] fetchFromHere(){
		Object[][] objArray= new Object[3][4];

		objArray[0][0]="Bibhudatta";
		objArray[0][1]="TYSS";
		objArray[0][2]="Created";
		objArray[0][3]=10;

		objArray[1][0]="Rakesh";
		objArray[1][1]="Sony";
		objArray[1][2]="Created";
		objArray[1][3]=20;

		objArray[2][0]="Iqbal";
		objArray[2][1]="Accenture";
		objArray[2][2]="Created";
		objArray[2][3]=5;

		return objArray;

	}
}













