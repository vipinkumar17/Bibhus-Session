package endToEnd;

import org.testng.Assert;
import org.testng.annotations.Test;

import genericUtility.BaseClassAPI;
import genericUtility.EndPointLibrery;
import genericUtility.JavaLibrery;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import pojoClass.ProjectLibrary;

public class CreateProjectAndVerifyInDatabase extends BaseClassAPI{

	@Test
	public void createAndVerify() throws Throwable {
		ProjectLibrary pLib = new ProjectLibrary("Bibhudatta", "tyss"+ jLib.getRandomNum(), "Created", 10);
		
		
		Response response = given()
				.body(pLib)
				.contentType(ContentType.JSON)
				.when()
				.post(EndPointLibrery.createProject);

		String proId = rLib.getJsonData(response, "projectId");

		response.then().log().all();

		String query= "select * from project";
		String data = dLib.executeQuery(query, 1, proId);

		Assert.assertEquals(proId, data);
	}
}




















