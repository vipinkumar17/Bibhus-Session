package practice_CRUD_with_BDD;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;


import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

import java.util.Random;

public class CreateProjectTest {

	@Test
	public void createProjectTest() {
		Random r= new Random();
		int ran= r.nextInt(100);
	
		baseURI="http://localhost";
		port=8084;
		
		
		
		//Step 1: create required data.
		JSONObject jobj= new JSONObject();
		jobj.put("createdBy", "Bibhudatta");
		jobj.put("projectName", "proj"+ran);
		jobj.put("status", "On Going");
		jobj.put("teamSize", 10);
		
		//Step 2: send request.
		//Step 3: Validate the response.
		given().body(jobj).contentType(ContentType.JSON)
		
		
		.when()
		.post("/addProject")
		
		.then()
		.assertThat().statusCode(201)
		.contentType(ContentType.JSON)
		.log().all();
			
			
		
		
		
		
	}
}
