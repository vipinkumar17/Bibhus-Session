package practice_CRUD_with_BDD;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class GetAllProjectsTest {

	@Test
	public void GetAllProjectsTest() {
		baseURI="http://localhost";
		port=8084;
		
		when()
		.get("/projects")
		
		.then()
			.assertThat().statusCode(200)
			.log().all();
		
	}
	
	@Test
	public void GetAllProjectsTest1() {

	
	}
	
	
}
