package practice_CRUD_with_BDD;

import org.testng.annotations.Test;

import io.restassured.RestAssured.*;

public class ComplexRequestInJSON {

	@Test
	public void newClass()
	{
		
	}
}
