package practice_CRUD_with_BDD;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class GetOneProjectTest {

	@Test
	public void GetOneProjectTest() {
		
	baseURI="http://localhost";
	port=8084;
	
	when()
	.get("/projects/TY_PROJ_2810")
	
	.then()
		.assertThat().statusCode(200)
		.log().all();
	
	
	
	}
}
