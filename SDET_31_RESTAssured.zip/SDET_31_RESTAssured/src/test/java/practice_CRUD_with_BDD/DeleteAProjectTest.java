package practice_CRUD_with_BDD;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

public class DeleteAProjectTest {

	@Test
	public void DeleteAProjectTest() {

	baseURI="http://localhost";
	port=8084;
	
	when()
	.delete("/projects/TY_PROJ_604")
	
	.then()
		.assertThat().statusCode(204)
		.log().all();
	
	
	
	
	}
}
