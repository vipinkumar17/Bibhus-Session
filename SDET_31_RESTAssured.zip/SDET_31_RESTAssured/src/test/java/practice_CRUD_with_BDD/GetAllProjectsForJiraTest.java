package practice_CRUD_with_BDD;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import genericUtility.ConstantLibrery;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;

import static io.restassured.RestAssured.*;

public class GetAllProjectsForJiraTest {

	@Test
	public void GetAllProjectsTest() {
		 
		baseURI="https://bibhudatta.atlassian.net";
		 Response response = given().
				 auth().basic("bibhudattasahu913@gmail.com", "MGDJ5ZPsbms0MslCqMrR4325")
		.when()
		.get("/rest/api/3/project/search");
	
		 response.then().log().all();
	}
	
	@Test 
	public void newJiraMethod()
	{
		HttpResponse<JsonNode> response = Unirest.get("https://bibhudatta.atlassian.net/rest/api/3/rest/api/project")
				  .basicAuth("bibhudattasahu913@gmail,com", "MGDJ5ZPsbms0MslCqMrR4325")
				  .header("Accept", "application/json")
				  .asJson();

				System.out.println(response.getBody());
	}
}
