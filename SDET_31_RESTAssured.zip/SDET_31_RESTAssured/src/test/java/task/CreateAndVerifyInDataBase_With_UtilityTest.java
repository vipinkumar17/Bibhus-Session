package task;

import org.testng.annotations.Test;

import genericUtility.BaseClassAPI;
import pojoClass.ProjectLibrary;

import static io.restassured.RestAssured.*;

public class CreateAndVerifyInDataBase_With_UtilityTest extends BaseClassAPI{

	@Test
	public void createAndVerify ()
	{
		ProjectLibrary pLib= new ProjectLibrary("Bibhudatta", "Tyss", "Created", 20);
		
	}
	
}
