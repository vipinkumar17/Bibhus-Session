package task;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import com.mysql.jdbc.Driver;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

public class CreateAndVerifyInDataBaseTest {
	
	@Test
	public void CreateAndVerify() {

		baseURI="http://localhost";
		port=8084;
		
		Random r= new Random();
		int random=r.nextInt(500);
		
		JSONObject j= new JSONObject();
		j.put("craetedBy", "Bibhudatta");
		j.put("projectName", "TYSS"+random);
		j.put("status", "Completed");
		j.put("teamSize", 10);

	given().body(j).contentType(ContentType.JSON)
	.when().post("/addProject")
	.then().assertThat().statusCode(201).log().all();

	
	
	
	}
	@Test
	public void verify() throws SQLException {
	Connection conn= null;
	try {
		Driver driverRef= new Driver();
		DriverManager.registerDriver(driverRef);
		
		conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/projects","root","root");
		System.out.println("connection is created");
		
		java.sql.Statement state= conn.createStatement();
		
		String query= "select * from project";
		
		ResultSet resultset= state.executeQuery(query);
		
		while(resultset.next()) {
			System.out.println(resultset.getString(1)+"\t"+ resultset.getString(2)+
					"\t"+ resultset.getString(3)+"\t"+resultset.getString(4));
		}
		
	} catch (Exception e) {
	}finally {
		conn.close();
		System.out.println("connection is closed");
	}
	}
	
}
