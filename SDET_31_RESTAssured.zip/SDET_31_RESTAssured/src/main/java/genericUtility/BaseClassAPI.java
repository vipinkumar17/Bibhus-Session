package genericUtility;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import static io.restassured.RestAssured.*;

/**
 * 
 * 
 * @author Lenovo
 *
 */
public class BaseClassAPI {
	
	public JavaLibrery jLib= new JavaLibrery();
	public DataBaseLibrery dLib= new DataBaseLibrery();
	public RestAssuredLibrery rLib= new RestAssuredLibrery();
	
	/**
	 * 
	 * 
	 * @throws Throwable
	 */
	@BeforeSuite
	public void bsConfigs() throws Throwable {
	
		baseURI="http://localhost";
		port=8084;
		
		dLib.connectToDB();
		System.out.println("data base connection done");
	}
	/**
	 * 
	 * 
	 * @throws Throwable
	 */
	@AfterSuite
	public void asConfigs() throws Throwable {
	
		dLib.closeDB();
		System.err.println("database connection closed");
	}
	

}
