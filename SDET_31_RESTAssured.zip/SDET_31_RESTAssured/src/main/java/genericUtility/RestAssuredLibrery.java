package genericUtility;

import static io.restassured.RestAssured.*;

import io.restassured.response.Response;

/**
 * This class is used for JSON data fetch using jsonPath.
 * 
 * @author Lenovo
 *
 */
public class RestAssuredLibrery {
	
	/**
	 * 
	 * 
	 * @param response
	 * @param path
	 * @return
	 */
	public String getJsonData(Response response , String path) {

		String jsonData = response.jsonPath().get(path);
		return jsonData;
	}
	/**
	 * This method is used to Log all the output into console.
	 * 
	 * @param response
	 */
	public void logAll(Response response) {
		response.then().log().all();
	}
}
