package genericUtility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.jdbc.Driver;

/**
 * This class is used to establish connection with Database, and 
 * 
 * @author Lenovo
 *
 */
public class DataBaseLibrery {

	Driver driverRef;
	Connection conn;
	
	/**
	 * 
	 * This method is used to establish connection with JDBC database. 
	 * @throws Throwable
	 */
	public void connectToDB() throws Throwable {
		driverRef= new Driver();
		DriverManager.registerDriver(driverRef);
		conn=DriverManager.getConnection(ConstantLibrery.dbUrl, ConstantLibrery.dbUsername, ConstantLibrery.dbPassword);
	}
	
	/**
	 * This method is used to close connection with JDBC database.
	 * @throws Throwable 
	 * 
	 */
	public void closeDB() throws Throwable {
		conn.close();
	}
	/**
	 * This method is used to execute querry in with JDBC database.
	 * Data fetch is done with the help of this method.
	 * @return 
	 * @throws Throwable 
	 * 
	 */
	public String executeQuery(String query, int colomnIndex, String expData) throws Throwable {
		boolean flag= false;
		ResultSet result = conn.createStatement().executeQuery(query);
		while(result.next())
		{
			String actData = result.getString(colomnIndex);
			
			if(expData.equalsIgnoreCase(actData))
			{
				flag= true;
				break;
			}
		}
		if(flag)
		{
			System.out.println("Data verified");
			return expData;
		}
		else
		{
			System.err.println("data not varified");
			return "";
		}
	}
}













