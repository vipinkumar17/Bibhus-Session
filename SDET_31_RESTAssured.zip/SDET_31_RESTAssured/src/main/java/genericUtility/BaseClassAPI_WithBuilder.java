package genericUtility;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseClassAPI_WithBuilder {
	
	public DataBaseLibrery dLib = new DataBaseLibrery();
	public RestAssuredLibrery rLib = new RestAssuredLibrery();
	public JavaLibrery jLib = new JavaLibrery();
	public RequestSpecification req;
	
	@BeforeSuite
	public void bsConfigs() throws Throwable {
		
		RequestSpecBuilder reqestSpecs= new RequestSpecBuilder();
		reqestSpecs.setContentType(ContentType.JSON);
		reqestSpecs.setBaseUri("http://localhost:8084");
		
		 req = reqestSpecs.build();
		 
		 dLib.connectToDB();
		 System.out.println("DataBase connection established");
	
		
	}
	@AfterSuite
	public void asConfigs() throws Throwable {
		dLib.closeDB();
		System.err.println("DataBase connection closed");
	}

}
