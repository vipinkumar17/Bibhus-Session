package genericUtility;
/**
 * This Interface is used to give credentials to connecting to DataBase.
 * This interface also contains credentials for RMGYantra application. 
 * @author Lenovo
 *
 */
public interface ConstantLibrery {

	String dbUrl="jdbc:mysql://localhost:3306/projects";
	String dbUsername="root";
	String dbPassword="root";
	
	String apiUsername="rmgyantra";
	String apiPassword="rmgy@9999";
	
	String jiraToken="H1oHSS5arXDDSeGhQQQr96BE";
}
