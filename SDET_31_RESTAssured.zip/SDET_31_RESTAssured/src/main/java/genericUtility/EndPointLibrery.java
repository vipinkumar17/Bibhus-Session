package genericUtility;

public interface EndPointLibrery {
	
	String createProject="/addProject";
	String getAllProjects="/projects";
	String getSingleProject="/projects/";
	String deleteProject= "/projects/";

}
