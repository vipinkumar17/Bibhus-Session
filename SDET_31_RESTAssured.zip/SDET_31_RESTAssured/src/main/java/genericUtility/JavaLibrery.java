package genericUtility;

import java.util.Random;
/**
 * This class is used to append Java codes in programm like randomNumber 
 * 
 * @author Lenovo
 *
 */
public class JavaLibrery {

	public int getRandomNum() {
		
		Random r= new Random();
		return r.nextInt(1000);
	}
}
